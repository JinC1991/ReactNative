/** The Branches foldout tabs. */
export enum BranchesTab {
  Branches = 0,
  PullRequests,
}
